# This is where we put small, helpful functions that are not exported.

