void R_init_caviarpd_rust(void *dll);
void R_init_caviarpd(void *dll) { R_init_caviarpd_rust(dll); }
