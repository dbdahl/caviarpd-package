#' @docType package
#' @usage NULL
#' @useDynLib caviarpd, .registration = TRUE
NULL
