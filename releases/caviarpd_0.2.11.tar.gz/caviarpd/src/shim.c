void R_init_caviarpd_librust(void *dll);
void R_init_caviarpd(void *dll) { R_init_caviarpd_librust(dll); }
